<nav class="menu">
    <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="clientes_inserir.php">Cadastrar Clientes</a></li>
        <li><a href="clientes_pesquisar.php">Pesquisar Clientes</a></li>
        <li><a href="contas_inserir.php">Cadastrar Contas</a></li>
        <li><a href="contas_pesquisar.php">Pesquisar Contas</a></li>
        <li><a href="logout.php">Sair</a></li>
    </ul>
</nav>