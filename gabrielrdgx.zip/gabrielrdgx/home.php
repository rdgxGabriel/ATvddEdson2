<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Despesas</title>
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/home.css">
</head>
<body>
    <?php
    require "menu.php"; // Importa o menu do sistema de Controle de Despesas
    ?>
    
    <br><br><br><br><br><center><img src="imagens/A.png" alt="Controle de Despesas"></center>
    <br><br><br><center><h1><strong>Controle de contas</strong></h1></center>
    <center>
        <p>
            O <strong>controle de contas</strong> é o processo de monitorar todas as operações financeiras de uma empresa, registrando suas entradas e saídas de capital.
        </p>
        <p>
            Isso inclui o acompanhamento de <em>contas a pagar</em>, também conhecidas como obrigações, como água, luz, salários dos empregados, entre outros.
        </p>
        <p>
            Com o controle de contas, você pode gerenciar suas finanças de forma eficiente, categorizando transações, gerando relatórios detalhados e estabelecendo metas financeiras.
        </p>
        <p>
            Além disso, destaca-se a <u>importância do planejamento financeiro</u> e da disciplina ao utilizar um sistema de controle de contas para manter a saúde financeira do seu negócio.
        </p>
    </center>
</body>
</html>
